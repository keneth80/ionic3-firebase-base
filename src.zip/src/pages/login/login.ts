import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';
import { AngularFireAuth } from 'angularfire2/auth';

import { RegisterPage } from '../register/register';
import { HomePage } from '../home/home';
import { AuthProvider } from '../../providers/auth/auth';

import { User } from '../models/user';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  public userId: string;
  _firstName: String;
  _gender: String;
  _lastName: String;
  _name: String;
  _data: any;
  user: any = {} as User;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private loadingCtrl: LoadingController,
    private afAuth: AngularFireAuth,
    private authService: AuthProvider,
    private facebook: Facebook) {
  }

  signin(user: User) {
    let loading = this.loadingCtrl.create({
      content: 'Loading...'
    });
    loading.present();

    this.authService.login(this.user)
      .then(auth => {
        loading.dismiss();
        this.navCtrl.setRoot(HomePage);
      })
      .catch(err => {
        loading.dismiss();
        alert(JSON.stringify(err));
      });
  }

  signup() {
    this.navCtrl.push(RegisterPage);
  }

  // facebookLogin() {
  //   this.facebook.login(['public_profile', 'user_friends', 'email', 'user_posts'])
  //     .then((res: FacebookLoginResponse) => {
  //       this.userId = res.authResponse.userID
  //       this.getUserInformation();
  //       // this.getUserFeeds();
  //       this.navCtrl.push('MyprofilePage', {
  //         firstName: this._firstName,
  //         lastName: this._lastName,
  //         name: this._name,
  //         gender: this._gender,
  //         data: this._data
  //       })

  //     })
  //     .catch(e => console.log('Error logging into Facebook', e));
  // }

  // getUserInformation() {
  //   this.facebook.getLoginStatus().then((response) => {
  //     if (response.status == 'connected') {
  //       this.facebook.api('/' + response.authResponse.userID + '?fields=id,name,gender,first_name,last_name', []).then((response) => {
  //         this._name = JSON.parse(JSON.stringify(response)).name;
  //         this._gender = JSON.parse(JSON.stringify(response)).gender;
  //         this._firstName = JSON.parse(JSON.stringify(response)).id;
  //         this._lastName = JSON.parse(JSON.stringify(response)).last_name;

  //         this.getUserFeeds();
  //       }, (error) => {
  //         alert(error);
  //       })
  //     }
  //   })
  // }

  // getUserFeeds() {
  //   this.facebook.getLoginStatus().then((res) => {
  //     if (res.status == 'connected') {
  //       this.facebook.api('/me/feed', []).then((res) => {
  //         this._data = res.data;
  //         // alert(JSON.stringify(this._data));
  //       }, (error) => {
  //         alert(error);
  //       })
  //     }
  //   })
  // }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

}
