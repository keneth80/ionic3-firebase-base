export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyDmC3mXOX6HAn6ugI-s7H-YfDBnZ-sN9hk",
    authDomain: "ionic-firebase-d219d.firebaseapp.com",
    databaseURL: "https://ionic-firebase-d219d.firebaseio.com",
    projectId: "ionic-firebase-d219d",
    storageBucket: "ionic-firebase-d219d.appspot.com",
    messagingSenderId: "506475390935"
};